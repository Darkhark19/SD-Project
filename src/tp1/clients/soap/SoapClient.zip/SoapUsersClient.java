package tp1.clients.soap;

import jakarta.xml.ws.BindingProvider;
import jakarta.xml.ws.Service;
import tp1.api.User;
import tp1.api.service.soap.SoapUsers;
import tp1.api.service.soap.UsersException;
import tp1.api.service.util.Result;
import tp1.api.service.util.Users;

import javax.xml.namespace.QName;
import java.net.URI;
import java.util.List;

public class SoapUsersClient extends SoapClient implements Users {
    private static final String WSDL = "/users?wsdl";
    private SoapUsers users;

    public SoapUsersClient(URI u){
        super();
        String serverUrl = u.toString() + WSDL;
        QName qname = new QName(SoapUsers.NAMESPACE, SoapUsers.NAME);
        Service service = Service.create( URI.create(serverUrl + "?wsdl").toURL(), qname);
        users = service.getPort(SoapUsers.class);
        setClientTimeouts( (BindingProvider)users);
    }
    @Override
    public Result<String> createUser(User user) {
        return super.reTry( () -> clt_createUser(user));
    }

    private Result<String> clt_createUser(User user) throws UsersException {
        var r = users.createUser(user);
        return Result.ok(r);


    }

    @Override
    public Result<User> getUser(String userId, String password) {
        return super.reTry( () -> clt_getUser(userId,password));
    }
    private Result<User> clt_getUser(String userId, String password) {
           /* var r = users.createUser(user);
            return Result.ok()*/

    }

    @Override
    public Result<User> updateUser(String userId, String password, User user) {
        return super.reTry( () -> clt_updateUser( userId,  password,  user));
    }

    private Result<User> clt_updateUser(String userId, String password, User user) {
    }

    @Override
    public Result<User> deleteUser(String userId, String password) {
        return null;
    }

    @Override
    public Result<List<User>> searchUsers(String pattern) {
        return null;
    }

    @Override
    public Result<User> userExists(String userId) {
        return null;
    }
}
